﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeliveryCharges
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Declare and load Arrays
            String[] ZipCodes = { "28713", "28734", "28779", "28771", "28719", "28901", "28906", "28786", "28904", "28801"};
            Double[] ShippingCharges = { 10.00, 11.00, 10.50, 11.00, 10.50, 11.00, 15.00, 12.00, 15.00, 20.00 };
      
            // I added a third Array to show Cities
            string[] Cities = { "Bryson City", "Franklin", "Sylva", "Robbinsville", "Cherokee", "Andrews", "Murphy", "Waynesville", "Hayesville", "Asheville" };

            // Declare Found Zipcodes Varables
            bool ZipcodeFound = false;
            int IndexFound=0;

            // Search Zipcode Array for Users Input
            for (int i = 0; i < ZipCodes.Length; i++) 
            {
                if (ZipCodes[i] == ZipCodeInput.Text)
                {
                    ZipcodeFound = true;
                    IndexFound = i;
                }
            }
            // Handle if found or not
            if (ZipcodeFound)
            {
                Results.Text = $"The shipping charge for {ZipCodes[IndexFound]} ({Cities[IndexFound]}) is {ShippingCharges[IndexFound].ToString("C")}.";
            }
            else 
            {
                Results.Text = $"We do not deliver to the requested zip code ({ZipCodeInput.Text}).";
            }
        }
    }
}
